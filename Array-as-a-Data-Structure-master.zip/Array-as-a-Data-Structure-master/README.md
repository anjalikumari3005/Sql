# C-Language
Array as a Data Structure
