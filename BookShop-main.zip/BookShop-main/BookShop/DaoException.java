package BookShop;


public class DaoException extends Exception {   //异常类

    public DaoException() {
        super();
    }

    public DaoException(String message, Throwable cause) {
        super(message, cause);
    }
}

