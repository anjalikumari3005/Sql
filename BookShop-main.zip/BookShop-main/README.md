- 👋 Hi, I’m @darkness-stark
- 👀 I’m interested in Java
- 🌱 I’m currently learning Java——Software development related knowledge.
- 💞️ I’m looking to collaborate on ...
- 📫 How to reach me ...

<!---
darkness-stark/darkness-stark is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
这是一个书店管理系统，内容：
(1)销售功能：购买书籍时，输入相应的ISBN号，并在书库中查找该书的相关信息。如果有库存量，输入购买的册数，进行相应计算。如果库存量不够，给出提示信息，结束购买。
(2)添加功能：主要完成图书信息的添加，要求ISBN号唯一。 当添加了重复的编号时，则提示数据添加重复并取消添加。
(3)查询功能：可按书名、ISBN号、作者、出版社进行查询。若存在相应信息，输出所查询的信息，若不存在该记录，则提示“该标题不存在!”。
(4)修改功能：可根据查询结果对相应的记录进行修改，修改时注意ISBN号的唯一性 。
(5)删除功能：主要完成图书信息的删除。输入要删除的ISBN号，根据编号删除该物品的记录，如果该编号不在物品库中，则提示“该编号不存在”。
(6)统计功能：输出当前书库中所有图书的总数及详细信息;可按书的价格、库存量、作者、出版社进行统计，输出统计信息时，要按从大到小进行排序。
(7)图书存盘：将当前程序中的图书信息存入文件中。
(8)读出信息：从文件中将图书信息读入程序。

这个系统以java语言为基础，用文件操作进行数据储存，没有界面设计和数据库连接，后续将会进行添加优化，适合学生java系统设计作业。

/***
This is a bookstore management system.
This system is based on the java language and uses files for data storage.
There is no interface and database design, which will be carried out later.
Java system design homework reference suitable for students.
***/
