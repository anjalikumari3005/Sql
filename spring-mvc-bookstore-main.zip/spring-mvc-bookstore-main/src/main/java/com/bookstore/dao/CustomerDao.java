package com.bookstore.dao;

public class CustomerDao {

}
