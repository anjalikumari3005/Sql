package com.bookstore.beans;

public class Customer {

}
