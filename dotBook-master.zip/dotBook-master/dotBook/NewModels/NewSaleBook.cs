﻿namespace dotBook.NewModels
{
    public class NewSaleBook
    {
        public int BookId { get; set; }
        public int Quantity { get; set; }
        public int Price { get; set; }
    }
}
