﻿namespace dotBook.NewModels
{
    public class NewStockOfBook
    {

        public int BookId { get; set; }
        public int Quantity { get; set; }

    }
}
