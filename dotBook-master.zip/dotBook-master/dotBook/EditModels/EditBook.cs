﻿namespace dotBook.EditModels
{
    public class EditBook
    {
        //public int Price { get; set; }
        public int Stock { get; set; }
        //public string? Description { get; set; }
    }
}
