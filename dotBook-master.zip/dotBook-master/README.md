# dotBook

My ASP.NET core WEB API Project with MySQL & Entity Framework Core

=> [hardik88t](https://github.com/hardik88t)
